#include "main.hpp"


namespace nodelet_namespace
{


nodelet_class::nodelet_class() {
}

void nodelet_class::onInit()
{
    ros::NodeHandle& private_nh = getNodeHandle();
    ros::NodeHandle& public_nh = getNodeHandle();
    image_transport::ImageTransport it(public_nh);
    NODELET_INFO_STREAM("Automatic Camera-Lidar Calibration");

    image_subscriber = public_nh.subscribe<sensor_msgs::Image>("/gmsl/A0/image_color", 10, &nodelet_class::ReceiveImage, this);
    pcl_subscriber = public_nh.subscribe<sensor_msgs::PointCloud2>("velodyne/front/points", 10, &nodelet_class::ReceivePcl, this);
    pub_img = it.advertise("/corner_points", 1);
}


void nodelet_class::ReceiveImage(const sensor_msgs::Image::ConstPtr &img) {
    cv_bridge::CvImagePtr cv_ptr;
    cv::Size2f patternNum(8, 6);
    cv::Size2i patternSize(65, 65);
  
    try
    {
      cv_ptr = cv_bridge::toCvCopy(img, sensor_msgs::image_encodings::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
    }
     
    cv::Mat gray; 
    std::vector<cv::Point2f> corners, corners_undistorted;
    std::vector<cv::Point3f> grid3dpoint;

    cv::cvtColor(cv_ptr->image, gray, CV_BGR2GRAY);
/*
    bool patternfound = cv::findChessboardCorners(gray, patternNum, corners, CALIB_CB_ADAPTIVE_THRESH + CALIB_CB_NORMALIZE_IMAGE);
    
    if(patternfound)
    {
        cornerSubPix(gray, corners, Size(11, 11), Size(-1, -1), TermCriteria(CV_TERMCRIT_EPS + CV_TERMCRIT_ITER, 30, 0.1));
        cv::Size imgsize;
        imgsize.height=cv_ptr->image.rows;
        imgsize.width=cv_ptr->image.cols;
        
        patternnum = patternNum;
        patternsize = patternSize;
        
        for(int i=0;i<patternnum.height;i++)
        {
            for(int j=0;j<patternnum.width;j++)
            {
                cv::Point3f tmpgrid3dpoint;
                tmpgrid3dpoint.x=i*patternsize.height-162.5;
                tmpgrid3dpoint.y=j*patternsize.width-227.5;
                tmpgrid3dpoint.z=0;
                grid3dpoint.push_back(tmpgrid3dpoint);
            }
        }

        cv::Mat rvec(3,3,cv::DataType<double>::type); // Initialization for pinhole and fisheye
        cv::Mat tvec(3,1,cv::DataType<double>::type);
        std::vector<cv::Point2f> image_points;
 
        if (fisheye_model) {
            // Undistort the image by applying the fisheye intrinsic parameters 
            cv::fisheye::undistortPoints(corners, corners_undistorted, cameramat, distcoeff, cameramat); //the final input param is the camera matrix in the new or rectified coordinate frame. We put this to be the same as cameramat or else it will be set to empty matrix by default.  
            cv::Mat fake_distcoeff = (Mat_<double>(4,1) << 0, 0, 0, 0);
            cv::solvePnP(grid3dpoint, corners_undistorted, cameramat, fake_distcoeff, rvec, tvec);  // Fisheye
            cv::fisheye::projectPoints(grid3dpoint, image_points, rvec, tvec, cameramat, distcoeff);
        }
        else {
            cv::solvePnP(grid3dpoint, corners, cameramat, distcoeff, rvec, tvec);  // Pinhole
            cv::projectPoints(grid3dpoint, rvec, tvec, cameramat, distcoeff, image_points);
        }

        std::vector< cv::Point3f > boardcorners;
        // board corners from the dimension of the board; In our case, the board centre is not equal to the checkerboard centre
        // Origin is at checkerboard centre. Measurements are in mm.
        boardcorners.push_back(cv::Point3f(300.0, 442.5, 0.0));
        boardcorners.push_back(cv::Point3f(-300.0, 442.5, 0.0));
        boardcorners.push_back(cv::Point3f(-300.0, -462.5, 0.0));
        boardcorners.push_back(cv::Point3f(300.0, -462.5, 0.0));
        boardcorners.push_back(cv::Point3f(0.0, -10.0, 0.0));
        
        std::vector< cv::Point3f > square_edge;
        // two of the centre square corners 
        square_edge.push_back(cv::Point3f(-32.5, -32.5, 0.0));
        square_edge.push_back(cv::Point3f(32.5, -32.5, 0.0));
        
        cv::fisheye::projectPoints(square_edge, imagePoints1, rvec, tvec, cameramat, distcoeff);
        // Mark the centre square corner points
        for (int i = 0; i < square_edge.size(); i++)
            cv::circle(cv_ptr->image, imagePoints1[i], 5, CV_RGB(255,0,0),-1);

        camera_data = 1;
        std::vector< cv::Point2f > imagePoints;
        cv::fisheye::projectPoints(boardcorners, imagePoints, rvec, tvec, cameramat, distcoeff);
        // Cordinate frame and board corner points visualization 
        cv::aruco::drawAxis(cv_ptr->image, cameramat, distcoeff, rvec, tvec, 200.0);

        for (int i = 0; i < boardcorners.size(); i++)
          cv::circle(cv_ptr->image, imagePoints[i], 5, CV_RGB(255,0,0),-1);

        // chessboardpose is a 3*4 transform matrix that transforms points in board frame to camera frame | R&T
        cv::Mat chessboardpose = cv::Mat::eye(4, 4, CV_64F);
        cv::Mat tmprmat = cv::Mat(3, 3, CV_64F);
        cv::Rodrigues(rvec, tmprmat);
        
        for(int j = 0; j < 3; j++)
        {
            for(int k = 0; k < 3; k++) 
            {            
              chessboardpose.at<double>(j,k)=tmprmat.at<double>(j,k);
            }
            chessboardpose.at<double>(j,3)=tvec.at<double>(j);
        }

        chessboard_normal.at<double>(0) = 0; chessboard_normal.at<double>(1) = 0; chessboard_normal.at<double>(2) = 1;
        chessboard_normal = chessboard_normal * chessboardpose(cv::Rect(0,0,3,3)).t();   

        for (int k = 0; k < boardcorners.size(); k++) {
          // take every point in boardcorners set
          cv::Point3f pt(boardcorners[k]); 
          for (int i = 0; i < 3; i++) {   
            // fill in the transformed points(i.e point coordinate in cam frame) col wise          
            corner_vectors.at<double>(i,k) = chessboardpose.at<double>(i,0)*pt.x + chessboardpose.at<double>(i,1)*pt.y + chessboardpose.at<double>(i,3);
            
          }
          
          double corner_pt[3];
          corner_pt[0] = corner_vectors.at<double>(0,k); corner_pt[1] = corner_vectors.at<double>(1,k); corner_pt[2] = corner_vectors.at<double>(2,k);
          
          double * img_coord = converto_imgpts(corner_pt);
          // Mark the centre and corner points
          if (k==0)
          cv::circle(cv_ptr->image, cv::Point(img_coord[0],img_coord[1]), 8, CV_RGB(0,255,0),-1); //g
          else if (k==1)
          cv::circle(cv_ptr->image, cv::Point(img_coord[0],img_coord[1]), 8, CV_RGB(255,255,0),-1); //y
          else if (k==2)
          cv::circle(cv_ptr->image, cv::Point(img_coord[0],img_coord[1]), 8, CV_RGB(0,0,255),-1); //b
          else if (k==3)
          cv::circle(cv_ptr->image, cv::Point(img_coord[0],img_coord[1]), 8, CV_RGB(255,0,0),-1); //r
          else
          cv::circle(cv_ptr->image, cv::Point(img_coord[0],img_coord[1]), 8, CV_RGB(255,255,255),-1); //w
                   
          delete[] img_coord;
        }       
        pub_img.publish(cv_ptr->toImageMsg()); 

    }
    else
        ROS_ERROR("PATTERN NOT FOUND");*/
}
void nodelet_class::ReceivePcl(const sensor_msgs::PointCloud2::ConstPtr &pc) {
    NODELET_INFO_STREAM("PC");
}

double * converto_imgpts(double * arr)
{  
  double tmpxC=arr[0]/arr[2];
  double tmpyC=arr[1]/arr[2];
  cv::Point2d planepointsC;     
  planepointsC.x=tmpxC;
  planepointsC.y=tmpyC;
  double r2=tmpxC*tmpxC+tmpyC*tmpyC;

  if (fisheye_model) 
  {
      double r1=pow(r2,0.5);
      double a0=std::atan(r1);
      double a1 = a0*(1 + distcoeff.at<double>(0)* pow(a0,2) + distcoeff.at<double>(1)* pow(a0,4) + distcoeff.at<double>(2)* pow(a0,6) + distcoeff.at<double>(3)* pow(a0,8));
      planepointsC.x=(a1/r1)*tmpxC;
      planepointsC.y=(a1/r1)*tmpyC;
      planepointsC.x= cameramat.at<double>(0,0)* planepointsC.x  + cameramat.at<double>(0,2); 
      planepointsC.y= cameramat.at<double>(1,1) *planepointsC.y + cameramat.at<double>(1,2);
  }
  else 
  {
      double tmpdist=1+distcoeff.at<double>(0)*r2+distcoeff.at<double>(1)*r2*r2+distcoeff.at<double>(4)*r2*r2*r2;
      planepointsC.x=tmpxC*tmpdist+2*distcoeff.at<double>(2)*tmpxC*tmpyC+distcoeff.at<double>(3)*(r2+2*tmpxC*tmpxC);
      planepointsC.y=tmpyC*tmpdist+distcoeff.at<double>(2)*(r2+2*tmpyC*tmpyC)+2*distcoeff.at<double>(3)*tmpxC*tmpyC;          
      planepointsC.x=cameramat.at<double>(0,0)*planepointsC.x+cameramat.at<double>(0,2);
      planepointsC.y=cameramat.at<double>(1,1)*planepointsC.y+cameramat.at<double>(1,2);
  }
  double * img_coord = new double[2];
  *(img_coord) = planepointsC.x; *(img_coord+1) = planepointsC.y; 
  return img_coord; 
}

}
