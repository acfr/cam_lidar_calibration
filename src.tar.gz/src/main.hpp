#include <iostream>

#include <pluginlib/class_list_macros.h>
#include <nodelet/nodelet.h>
#include <ros/ros.h>

#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/image_encodings.h>

#include <image_transport/image_transport.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv/cv.hpp>
#include <cv_bridge/cv_bridge.h>
#include "opencv2/aruco.hpp"
#include <opencv2/calib3d.hpp>
#include <stdio.h>
#include <math.h> //fabs

using namespace cv;

namespace nodelet_namespace
{
int fisheye_model = 1;
  /* Params for Pinhole
  cv::Mat distcoeff = (cv::Mat_<double>(8,1) <<  -3.7069900000000000e-01, 1.4042499999999999e-01, -3.3700000000000001e-04, 1.9000000000000001e-05, -2.5448999999999999e-02, 0.0, 0.0, 0.0); 
  cv::Mat cameramat = (cv::Mat_<double>(3,3) << 1.1909306059999999e+03, 0.0, 9.6621625100000006e+02, 0.0, 1.1937946880000000e+03, 6.0846083699999997e+02, 0.0, 0.0, 0.1);
*/ 
cv::Mat distcoeff = (cv::Mat_<double>(1,4) << -0.05400957120448697, -0.07842753582468161, 0.09596410068935728, -0.05152529532743679); 
cv::Mat cameramat = (cv::Mat_<double>(3,3) << 1176.931662006163, 0.0, 962.2754188883206, 0.0, 1177.715660133758, 612.7245350750861, 0.0, 0.0, 1.0);

class nodelet_class : public nodelet::Nodelet
{
public:
  nodelet_class();
  void ReceiveImage(const sensor_msgs::Image::ConstPtr &img);
  void ReceivePcl(const sensor_msgs::PointCloud2::ConstPtr &pc);
  double * converto_imgpts(double * arr);
  
private:

  virtual void onInit();
  ros::Subscriber image_subscriber;
  ros::Subscriber pcl_subscriber;
  image_transport::Publisher pub_img;
  cv::Mat inliers; cv::Size2f patternsize; cv::Size2i patternnum;
  std::vector< cv::Point2f > imagePoints1; 
  cv::Mat chessboard_normal=cv::Mat(1,3,CV_64F); 
  cv::Mat corner_vectors=cv::Mat::eye(3,5,CV_64F); 
  int camera_data = 0;

  cv_bridge::CvImagePtr cv_ptr;
  cv::Size2f patternNum(8, 6);
  cv::Size2i patternSize(65, 65);
  cv::Mat gray; 
  std::vector<cv::Point2f> corners, corners_undistorted;
  std::vector<cv::Point3f> grid3dpoint;
 
};

PLUGINLIB_DECLARE_CLASS(nodelet_namespace, nodelet_class, nodelet_namespace::nodelet_class, nodelet::Nodelet);
}
